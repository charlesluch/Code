#!/usr/bin/env python3

import sys

def main():

    RC = 0

    if(RC == 0):
        return sys.exit(1)
    else:
        return sys.exit(0)

main()
